package ma.ens;

public class Point {

    private double x;
    private double y;

    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() { return x; }
    public double getY() { return y; }

    // Retourne le point résultant de la translation (a, b) appliquée sur this
    public Point translation(double a, double b) {
        return new Point(x + a, y + b);
    }

    // Distance entre deux points : sqrt((x2-x1)^2 + (y2-y1)^2)
    public static double distance(Point p1, Point p2) {
        return Math.sqrt(Math.pow(p2.x - p1.x, 2) + Math.pow(p2.y - p1.y, 2));
    }

    // Format attendu : "( 1.0 , 3.0 )"
    @Override
    public String toString() {
        return "( " + x + " , " + y + " )";
    }
}


