/**
 * 
 */
/**
 * 
 */
module classeobject {
}