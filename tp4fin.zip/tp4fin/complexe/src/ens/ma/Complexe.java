package ens.ma;

public class Complexe {
	    private double reel;
	    private double imaginaire;

	    public Complexe(double reel, double imaginaire) {
	        this.reel = reel;
	        this.imaginaire = imaginaire;
	    }

	    public double getReel() { return reel; }
	    public double getImaginaire() { return imaginaire; }


	    public Complexe plus(Complexe c) {
	        return new Complexe(reel + c.reel, imaginaire + c.imaginaire);
	    }

	    
	    public Complexe moins(Complexe c) {
	        return new Complexe(reel - c.reel, imaginaire - c.imaginaire);
	    }
	    private static String fmt(double v) {
	        return (v == Math.rint(v)) ? String.valueOf((long) v) : String.valueOf(v);
	    }

	 
	    @Override
	    public String toString() {
	        String signe = (imaginaire >= 0) ? "+" : "-";
	        return fmt(reel) + " " + signe + fmt(Math.abs(imaginaire)) + "i";
	    }
	


}
